class InventoryItem {
  constructor(name, description, weight) {
    this.name = name;
    this.description = description;
    this.weight = weight; // Optional: could be used for encumbrance systems
  }
}
export default InventoryItem;
