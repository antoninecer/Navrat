const CharacterAttributes = {
  genderModifiers: {
    Male: {
      strength: 1,
      speed: 0,
      agility: 0,
    },
    Female: {
      strength: -1,
      speed: 1,
      agility: 1,
    },
  },
};
export default CharacterAttributes;
