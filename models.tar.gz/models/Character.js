class Character {
  constructor(name, race, characterClass, abilities, inventory) {
    this.name = name;
    this.race = race; // Instance Race
    this.characterClass = characterClass; // Instance Class
    this.abilities = abilities; // Array of Ability instances
    this.inventory = inventory; // Array of InventoryItem instances
  }

  addAbility(ability) {
    this.abilities.push(ability);
  }

  addItemToInventory(item) {
    this.inventory.push(item);
  }

  getCharacterSummary() {
    return `
      Name: ${this.name}
      Race: ${this.race.name}
      Class: ${this.characterClass.name}
      Abilities: ${this.abilities.map(a => a.name).join(', ')}
      Inventory: ${this.inventory.map(i => i.name).join(', ')}
    `;
  }
}

export default Character;

