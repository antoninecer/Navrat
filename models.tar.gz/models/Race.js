class Race {
  constructor(name, traits) {
    this.name = name;
    this.traits = traits; // Array of traits (e.g., Darkvision, etc.)
  }
}

export default Race;

