class Ability {
  constructor(name, description) {
    this.name = name;
    this.description = description;
  }
}

export default Ability;

