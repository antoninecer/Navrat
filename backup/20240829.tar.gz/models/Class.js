class Class {
  constructor(name, hitDice, primaryAbility) {
    this.name = name;
    this.hitDice = hitDice; // Example: 'd8'
    this.primaryAbility = primaryAbility; // Example: 'Strength'
  }
}
export default Class;
