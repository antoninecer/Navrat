import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Button,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { averageGpsCoordinates } from "../components/gpsUtils"; // Import průměrovací funkce
import { t } from "../i18n"; // Import funkce pro překlady
import MapView, { Marker } from "react-native-maps";

export default function ReturnPointScreen() {
  const [location, setLocation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const navigation = useNavigation();

  const recalculateGps = async () => {
    setLoading(true);
    try {
      const averagedCoords = await averageGpsCoordinates();
      setLocation(averagedCoords);
    } catch (error) {
      setErrorMsg(error.message);
    }
    setLoading(false);
  };

  useEffect(() => {
    recalculateGps();
  }, []);

  return (
    <View style={styles.container}>
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0000ff" />
          <Text>{t("calculating_gps")}</Text>
        </View>
      ) : errorMsg ? (
        <Text style={styles.error}>{errorMsg}</Text>
      ) : (
        <View style={styles.content}>
          <Text>
            {t("gps_coordinates")}:{" "}
            {location
              ? `${location.latitude}, ${location.longitude}`
              : t("no_coordinates")}
          </Text>
          <View style={styles.mapContainer}>
            <MapView
              style={styles.map}
              region={{
                latitude: location ? location.latitude : 0,
                longitude: location ? location.longitude : 0,
                latitudeDelta: 0.01,
                longitudeDelta: 0.01,
              }}
              showsUserLocation={true}
              onRegionChangeComplete={(region) => setLocation(region)}
            >
              {location && (
                <Marker
                  coordinate={{
                    latitude: location.latitude,
                    longitude: location.longitude,
                  }}
                  title={t("return_point")}
                />
              )}
            </MapView>
          </View>
          <View style={styles.buttonContainer}>
            <Button title={t("recalculate_gps")} onPress={recalculateGps} />
            <Button
              title={t("view_point")}
              onPress={() =>
                navigation.navigate("PointScreen", { pointType: "Return" })
              }
            />
            <Button title={t("go_back")} onPress={() => navigation.goBack()} />
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  loadingContainer: {
    alignItems: "center",
  },
  content: {
    alignItems: "center",
    width: "100%",
  },
  mapContainer: {
    height: "50%", // Mapa zabere horní polovinu obrazovky
    width: "100%",
    marginVertical: 20,
  },
  buttonContainer: {
    marginTop: 20,
    width: "100%",
    justifyContent: "space-between",
    alignItems: "center",
  },
  error: {
    color: "red",
  },
  map: {
    width: "100%",
    height: "100%",
  },
});
